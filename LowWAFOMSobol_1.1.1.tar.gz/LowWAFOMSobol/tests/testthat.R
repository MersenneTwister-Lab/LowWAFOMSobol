library(testthat)
test_check("LowWAFOMSobol")
